:orphan:

Languages
=========

.. pygmentsdoc:: lexers_overview

... that's all?
---------------

Well, why not write your own? Contributing to Pygments is easy and fun. Take a
look at the :doc:`docs on lexer development <docs/lexerdevelopment>`. Pull
requests are welcome on `GitHub <https://github.com/pygments/pygments>`_.

.. note:: 
    
    The languages listed here are supported in the development version. The
    latest release may lack a few of them.
