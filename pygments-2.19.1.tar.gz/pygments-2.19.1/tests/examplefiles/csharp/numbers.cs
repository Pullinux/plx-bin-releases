public class CSharpNumbers
{
    public int[] TheInts = { 123, 10543765Lu, 0xFf, 0X1ba044fEL, 0x1ade3FE129AaUL, 0xabc, 0x123, 0b101, 0B10011010u, 0b111111110000UL, 0B111 };
    public float[] TheReals = { 1.234567, 1.3e5f, .3e5f, 2345E-20, 15D, 19.73M, 1.2F, 1.2f, .3e5F };
}